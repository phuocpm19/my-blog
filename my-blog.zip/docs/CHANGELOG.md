# Changelog

## [Unreleased]

### 2026-02-25
- **chore:** Khởi tạo monorepo structure (npm workspaces)
- **docs:** Tạo bộ documentation (PROJECT_OVERVIEW, ARCHITECTURE, DATABASE_SCHEMA, FEATURES, DECISIONS, CURRENT_PROGRESS)
- **chore:** Setup Next.js + Ant Design cho client app
- **chore:** Setup Next.js + Ant Design cho admin app
